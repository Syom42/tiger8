
  # High-fidelity design for Tiger8

  This is a code bundle for High-fidelity design for Tiger8. The original project is available at https://www.figma.com/design/SFMrCJ6JYCzSuic56IF0VN/High-fidelity-design-for-Tiger8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  