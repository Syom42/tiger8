import { useState, useEffect, type ReactNode, type ElementType } from "react";
import {
  LayoutDashboard, Dumbbell, CalendarDays, Clock, Trophy,
  Scale, Pill, User, Bot, Plus, Minus, Check, X, Play,
  RotateCcw, Search, Sun, Moon, Settings, AlertTriangle,
  Send, Edit3, Trash2, Bell, Flame, Target, BarChart3,
  Timer, CheckCircle, ArrowUp, Filter, WifiOff, Loader2,
  ChevronDown, RefreshCw, Star, Zap, Activity,
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | "dashboard" | "plans" | "workout" | "history"
  | "records" | "bodyweight" | "supplements" | "profile" | "ai";

type WorkoutSet = { weight: number; reps: number; done: boolean };
type WorkoutExercise = {
  id: number; name: string; sets: WorkoutSet[];
  lastSession: string; pr: number;
};

// ─── Mock Data ────────────────────────────────────────────────────────────────

const weeklyVolumeData = [
  { week: "ש1", volume: 8400 },
  { week: "ש2", volume: 9200 },
  { week: "ש3", volume: 7800 },
  { week: "ש4", volume: 10100 },
  { week: "ש5", volume: 9600 },
  { week: "ש6", volume: 11200 },
];

const squatProgressData = [
  { date: "ינו", weight: 100 },
  { date: "פבר", weight: 110 },
  { date: "מרץ", weight: 115 },
  { date: "אפר", weight: 120 },
  { date: "מאי", weight: 125 },
  { date: "יונ", weight: 130 },
  { date: "יול", weight: 140 },
];

const benchProgressData = [
  { date: "ינו", weight: 70 },
  { date: "פבר", weight: 80 },
  { date: "מרץ", weight: 85 },
  { date: "אפר", weight: 90 },
  { date: "מאי", weight: 92.5 },
  { date: "יונ", weight: 97.5 },
  { date: "יול", weight: 100 },
];

const deadliftProgressData = [
  { date: "ינו", weight: 130 },
  { date: "פבר", weight: 145 },
  { date: "מרץ", weight: 155 },
  { date: "אפר", weight: 160 },
  { date: "מאי", weight: 165 },
  { date: "יונ", weight: 175 },
  { date: "יול", weight: 180 },
];

const bodyweightData = [
  { date: "1/6", w: 81.2 },
  { date: "8/6", w: 81.8 },
  { date: "15/6", w: 82.1 },
  { date: "22/6", w: 82.4 },
  { date: "29/6", w: 82.3 },
  { date: "5/7", w: 82.8 },
  { date: "12/7", w: 83.0 },
  { date: "19/7", w: 83.1 },
];

const recentWorkouts = [
  { id: 1, name: "כוח עליון A", date: "אמש", duration: "52 דק׳", volume: "4,200", sets: 18 },
  { id: 2, name: "כוח תחתון B", date: "שלשום", duration: "61 דק׳", volume: "6,800", sets: 20 },
  { id: 3, name: "כוח עליון A", date: "לפני 4 ימים", duration: "48 דק׳", volume: "3,900", sets: 18 },
  { id: 4, name: "כוח תחתון B", date: "לפני 6 ימים", duration: "65 דק׳", volume: "7,100", sets: 22 },
  { id: 5, name: "כוח עליון A", date: "לפני 8 ימים", duration: "55 דק׳", volume: "4,400", sets: 18 },
];

const weeklyPlan = [
  { day: "א", label: "ראשון", workout: "כוח עליון A", status: "done" as const },
  { day: "ב", label: "שני", workout: "מנוחה", status: "done" as const },
  { day: "ג", label: "שלישי", workout: "כוח תחתון B", status: "done" as const },
  { day: "ד", label: "רביעי", workout: "מנוחה", status: "done" as const },
  { day: "ה", label: "חמישי", workout: "כוח עליון A", status: "today" as const },
  { day: "ו", label: "שישי", workout: "כוח תחתון B", status: "upcoming" as const },
  { day: "ש", label: "שבת", workout: "מנוחה", status: "upcoming" as const },
];

const personalRecords = [
  { exercise: "סקוואט", weight: 140, date: "15/7/25", delta: "+10", isPR: true, data: squatProgressData },
  { exercise: "דדליפט", weight: 180, date: "8/7/25", delta: "+5", isPR: true, data: deadliftProgressData },
  { exercise: "לחיצת חזה", weight: 100, date: "1/7/25", delta: "+2.5", isPR: true, data: benchProgressData },
  { exercise: "לחיצת כתפיים", weight: 75, date: "22/6/25", delta: "+5", isPR: false, data: squatProgressData.map(d => ({ ...d, weight: d.weight * 0.54 })) },
  { exercise: "משיכת מוט", weight: 90, date: "15/6/25", delta: "+5", isPR: false, data: squatProgressData.map(d => ({ ...d, weight: d.weight * 0.65 })) },
  { exercise: "כפיפות מרפקים", weight: 40, date: "1/6/25", delta: "+2.5", isPR: false, data: squatProgressData.map(d => ({ ...d, weight: d.weight * 0.29 })) },
];

const initialWorkoutExercises: WorkoutExercise[] = [
  {
    id: 1, name: "לחיצת חזה", pr: 100, lastSession: "75 ק״ג × 5",
    sets: Array(5).fill(null).map(() => ({ weight: 80, reps: 5, done: false })),
  },
  {
    id: 2, name: "משיכת מוט", pr: 90, lastSession: "67.5 ק״ג × 5",
    sets: Array(5).fill(null).map(() => ({ weight: 70, reps: 5, done: false })),
  },
  {
    id: 3, name: "לחיצת כתפיים", pr: 75, lastSession: "52.5 ק״ג × 5",
    sets: Array(3).fill(null).map(() => ({ weight: 55, reps: 5, done: false })),
  },
];

const plans = [
  { id: 1, name: "כוח מלא 5×5", days: 3, type: "כוח", level: "מתקדם", desc: "5 סטים × 5 חזרות בתרגילים בסיסיים" },
  { id: 2, name: "היפרטרופיה A/B", days: 4, type: "מסה", level: "בינוני", desc: "פיצול עליון/תחתון, 8-12 חזרות" },
  { id: 3, name: "כוח + מסה PPL", days: 6, type: "מסה/כוח", level: "מתקדם", desc: "דחיפה/משיכה/רגליים — 6 ימים" },
  { id: 4, name: "מתחיל 3×8", days: 3, type: "כללי", level: "מתחיל", desc: "3 ימי אימון, בניית בסיס כוח" },
];

const supplements = [
  { id: 1, name: "קריאטין מונוהידראט", dose: "5 גרם", timing: "בוקר", freq: "יומי", active: true },
  { id: 2, name: "חלבון מי גבינה", dose: "30 גרם", timing: "אחרי אימון", freq: "ימי אימון", active: true },
  { id: 3, name: "ויטמין D3", dose: "2,000 IU", timing: "בוקר", freq: "יומי", active: true },
  { id: 4, name: "אומגה 3", dose: "1 גרם", timing: "ערב", freq: "יומי", active: true },
  { id: 5, name: "מגנזיום גליצינאט", dose: "400 מ\"ג", timing: "לפני שינה", freq: "יומי", active: false },
];

const aiMessages = [
  { role: "ai" as const, text: "שלום עמית. שיא אישי בסקוואט השבוע — 140 ק\"ג. עבודה מצוינת. יש משהו שתרצה לעבוד עליו?" },
  { role: "user" as const, text: "רוצה להגיע ל-110 בלחיצת חזה עד אוקטובר." },
  { role: "ai" as const, text: "יעד ריאלי — עלייה של 10% ב-3 חודשים. ממליץ להוסיף יום חזה ייעודי עם 4×8 בטווח צמיחה, ולחזק טריספס עם פשיטות מרפקים. רוצה שאכין תוכנית?" },
];

// ─── Primitives ───────────────────────────────────────────────────────────────

function cn(...args: (string | undefined | false | null)[]) {
  return args.filter(Boolean).join(" ");
}

function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div
      className={cn("bg-card border border-border rounded-lg", onClick && "cursor-pointer", className)}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

function SectionLabel({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{children}</h2>
      {action && <div className="text-xs text-muted-foreground">{action}</div>}
    </div>
  );
}

type BtnVariant = "primary" | "secondary" | "ghost" | "destructive" | "outline";
type BtnSize = "xs" | "sm" | "md" | "lg";

function Btn({
  children, variant = "primary", size = "md", onClick, className, disabled, fullWidth,
}: {
  children: ReactNode; variant?: BtnVariant; size?: BtnSize;
  onClick?: () => void; className?: string; disabled?: boolean; fullWidth?: boolean;
}) {
  const base = "inline-flex items-center justify-center gap-1.5 font-medium transition-colors rounded focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:opacity-50 disabled:pointer-events-none";
  const vs: Record<BtnVariant, string> = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/80",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    ghost: "text-foreground hover:bg-accent",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    outline: "border border-border text-foreground hover:bg-accent",
  };
  const ss: Record<BtnSize, string> = {
    xs: "h-7 px-2.5 text-xs",
    sm: "h-8 px-3 text-xs",
    md: "h-9 px-4 text-sm",
    lg: "h-11 px-6 text-base",
  };
  return (
    <button
      className={cn(base, vs[variant], ss[size], fullWidth && "w-full", className)}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

type BadgeVariant = "default" | "gold" | "green" | "red" | "muted" | "blue";

function Badge({ children, variant = "default" }: { children: ReactNode; variant?: BadgeVariant }) {
  const vs: Record<BadgeVariant, string> = {
    default: "bg-secondary text-secondary-foreground",
    gold: "text-[var(--gold)] bg-[var(--gold)]/12",
    green: "text-primary bg-primary/12",
    red: "text-destructive bg-destructive/12",
    muted: "bg-muted text-muted-foreground",
    blue: "text-sky-600 bg-sky-600/10 dark:text-sky-400 dark:bg-sky-400/10",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium", vs[variant])}>
      {children}
    </span>
  );
}

function StatCard({
  label, value, sub, icon: Icon, accent, mono = true,
}: {
  label: string; value: string; sub?: string;
  icon?: ElementType; accent?: "gold" | "green" | "red"; mono?: boolean;
}) {
  const color = accent === "gold" ? "text-[var(--gold)]" : accent === "green" ? "text-primary" : accent === "red" ? "text-destructive" : "text-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground mb-1.5 leading-none">{label}</p>
          <p className={cn("text-2xl font-bold leading-none", mono && "font-mono tabular-nums", color)}>{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-1.5 leading-none">{sub}</p>}
        </div>
        {Icon && <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />}
      </div>
    </Card>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={cn("relative w-10 h-6 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring", value ? "bg-primary" : "bg-muted")}
    >
      <span className={cn("absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm", value ? "right-1" : "right-5")} />
    </button>
  );
}

function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded bg-muted", className)} />;
}

function EmptyState({ icon: Icon, title, desc, action }: {
  icon: ElementType; title: string; desc: string; action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="font-medium text-sm mb-1">{title}</p>
      <p className="text-xs text-muted-foreground mb-4 max-w-xs">{desc}</p>
      {action}
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function DashboardScreen({ onStartWorkout }: { onStartWorkout: () => void }) {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return (
      <div className="p-6 space-y-6 max-w-4xl">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <Skeleton className="h-3 w-40" />
            <Skeleton className="h-7 w-32" />
          </div>
          <Skeleton className="h-6 w-28 rounded-full" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20 rounded-lg" />)}
        </div>
        <Skeleton className="h-48 rounded-lg" />
        <div className="grid grid-cols-7 gap-1">
          {[...Array(7)].map((_, i) => <Skeleton key={i} className="h-16 rounded" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground mb-1">יום חמישי, 17 יולי 2025</p>
          <h1 className="text-2xl font-bold">שלום, עמית</h1>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="green">
            <Flame className="w-3 h-3" />
            12 ימים רצף
          </Badge>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="אימונים השבוע" value="4" sub="מתוך 6 מתוכנן" icon={Dumbbell} accent="green" />
        <StatCard label="עמידה ביעד" value="67%" sub="7 ימים אחרונים" icon={Target} />
        <StatCard label="נפח שבועי" value="11.2K" sub="ק״ג כולל" icon={BarChart3} accent="green" />
        <StatCard label="שיא אחרון" value="140" sub="סקוואט ק״ג" icon={Trophy} accent="gold" />
      </div>

      {/* Today's workout */}
      <div>
        <SectionLabel>אימון היום</SectionLabel>
        <Card className="p-5">
          <div className="flex items-start gap-4 mb-4">
            <div className="flex-1">
              <h3 className="font-bold text-lg leading-tight">כוח עליון A</h3>
              <p className="text-sm text-muted-foreground mt-0.5">3 תרגילים · 13 סטים · כ-50 דקות</p>
            </div>
            <Btn onClick={onStartWorkout} size="lg">
              <Play className="w-4 h-4" />
              התחל אימון
            </Btn>
          </div>
          <div className="space-y-0 divide-y divide-border">
            {initialWorkoutExercises.map((ex, i) => (
              <div key={ex.id} className="flex items-center justify-between py-2.5 first:pt-0 last:pb-0">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">{i + 1}</span>
                  <span className="text-sm font-medium">{ex.name}</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="font-mono">{ex.sets.length}×{ex.sets[0].reps}</span>
                  <span className="font-mono font-medium text-foreground">{ex.sets[0].weight} ק״ג</span>
                  <Badge variant="gold">שיא {ex.pr}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Weekly grid */}
      <div>
        <SectionLabel>שבוע נוכחי</SectionLabel>
        <div className="grid grid-cols-7 gap-1.5">
          {weeklyPlan.map(d => (
            <div
              key={d.day}
              className={cn(
                "rounded-lg p-2 text-center flex flex-col items-center gap-1 min-h-[60px] justify-center",
                d.status === "done" && "bg-primary/10",
                d.status === "today" && "bg-primary",
                d.status === "upcoming" && "bg-muted",
              )}
            >
              <span className={cn("text-xs font-semibold", d.status === "today" ? "text-primary-foreground" : "text-muted-foreground")}>{d.day}</span>
              {d.status === "done" && <Check className="w-3.5 h-3.5 text-primary" />}
              {d.status === "today" && <span className="w-1.5 h-1.5 rounded-full bg-primary-foreground/70" />}
              {d.status === "upcoming" && (
                <span className="text-[10px] text-muted-foreground leading-tight hidden sm:block">
                  {d.workout === "מנוחה" ? "מנוחה" : "·"}
                </span>
              )}
              <span className={cn("text-[9px] leading-tight font-medium hidden md:block", d.status === "today" ? "text-primary-foreground/80" : "text-muted-foreground/70")}>
                {d.workout === "מנוחה" ? "מנוחה" : d.workout.split(" ").slice(0, 2).join(" ")}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent + Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div>
          <SectionLabel action={<button className="text-primary hover:underline">הכל</button>}>אימונים אחרונים</SectionLabel>
          <div className="space-y-2">
            {recentWorkouts.slice(0, 3).map(w => (
              <Card key={w.id} className="flex items-center justify-between p-3 px-4 hover:border-primary/30 transition-colors">
                <div>
                  <p className="text-sm font-medium">{w.name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{w.date} · {w.duration}</p>
                </div>
                <div className="text-left">
                  <p className="text-sm font-mono font-semibold">{w.volume} <span className="text-xs text-muted-foreground font-normal">ק״ג</span></p>
                  <p className="text-xs text-muted-foreground">{w.sets} סטים</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
        <div>
          <SectionLabel>נפח שבועי</SectionLabel>
          <Card className="p-4">
            <div dir="ltr">
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={weeklyVolumeData} barSize={18} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="week" tick={{ fontSize: 11, fill: "var(--muted-foreground)", fontFamily: "Heebo" }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip
                    contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 12, fontFamily: "Heebo", direction: "rtl" }}
                    formatter={(v: unknown) => [`${((v as number) / 1000).toFixed(1)}K ק״ג`, "נפח"]}
                    cursor={{ fill: "var(--accent)" }}
                  />
                  <Bar dataKey="volume" fill="var(--primary)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── Plans ────────────────────────────────────────────────────────────────────

function PlansScreen() {
  const [search, setSearch] = useState("");
  const [active, setActive] = useState<number | null>(1);
  const filtered = plans.filter(p =>
    p.name.includes(search) || p.type.includes(search) || p.level.includes(search)
  );

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">ספריית תוכניות</h1>
        <Btn variant="primary" size="sm">
          <Plus className="w-3.5 h-3.5" />
          תוכנית חדשה
        </Btn>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="חפש לפי שם, סוג, רמה..."
          className="w-full h-9 bg-input-background border border-border rounded pr-9 pl-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={Search}
          title="לא נמצאו תוכניות"
          desc="נסה לחפש עם מילת מפתח אחרת"
          action={<Btn variant="outline" size="sm" onClick={() => setSearch("")}>נקה חיפוש</Btn>}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map(plan => (
            <Card
              key={plan.id}
              className={cn("p-4 hover:border-primary/40 transition-all", active === plan.id && "ring-2 ring-primary/40 border-primary/40")}
              onClick={() => setActive(plan.id)}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <h3 className="font-semibold">{plan.name}</h3>
                    {active === plan.id && <Badge variant="green">פעיל</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{plan.desc}</p>
                </div>
                <Badge variant={plan.level === "מתקדם" ? "red" : plan.level === "בינוני" ? "gold" : "muted"}>
                  {plan.level}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground mt-3">
                <span className="flex items-center gap-1">
                  <CalendarDays className="w-3 h-3" />
                  {plan.days} ימים/שבוע
                </span>
                <span className="flex items-center gap-1">
                  <Dumbbell className="w-3 h-3" />
                  {plan.type}
                </span>
              </div>
              <div className="mt-3 pt-3 border-t border-border flex gap-2">
                <Btn
                  variant={active === plan.id ? "secondary" : "primary"}
                  size="sm"
                  className="flex-1"
                  onClick={e => { e.stopPropagation(); setActive(plan.id); }}
                >
                  {active === plan.id ? <Check className="w-3 h-3" /> : null}
                  {active === plan.id ? "נבחר" : "בחר תוכנית"}
                </Btn>
                <Btn variant="outline" size="sm">פרטים</Btn>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Weekly scheduler */}
      <div>
        <SectionLabel>לוח שבועי — שיבוץ ידני</SectionLabel>
        <Card className="p-4">
          <div className="grid grid-cols-7 gap-2">
            {weeklyPlan.map(d => (
              <div key={d.day} className="flex flex-col gap-1.5">
                <span className="text-xs text-center text-muted-foreground font-semibold">{d.day}</span>
                <div className={cn(
                  "rounded border border-dashed p-2 text-center min-h-[56px] flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-primary/50 transition-colors text-xs",
                  d.status === "done" ? "bg-primary/8 border-primary/30" : "border-border",
                  d.status === "today" && "bg-primary/15 border-primary/60",
                )}>
                  {d.workout === "מנוחה" ? (
                    <span className="text-muted-foreground text-[10px]">מנוחה</span>
                  ) : (
                    <>
                      <Dumbbell className="w-3 h-3 text-primary" />
                      <span className="text-[9px] text-primary font-semibold leading-tight">{d.workout}</span>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3 text-center">לחץ על יום לשיוך תוכנית</p>
        </Card>
      </div>
    </div>
  );
}

// ─── Active Workout ───────────────────────────────────────────────────────────

function WorkoutScreen({ onExit }: { onExit: () => void }) {
  const [exercises, setExercises] = useState<WorkoutExercise[]>(
    JSON.parse(JSON.stringify(initialWorkoutExercises))
  );
  const [restTimer, setRestTimer] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [showExit, setShowExit] = useState(false);
  const [prExercise, setPrExercise] = useState<string | null>(null);

  useEffect(() => {
    const t = setInterval(() => setElapsed(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (restTimer === null || restTimer <= 0) { if (restTimer === 0) setRestTimer(null); return; }
    const t = setTimeout(() => setRestTimer(s => (s ?? 1) - 1), 1000);
    return () => clearTimeout(t);
  }, [restTimer]);

  const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

  const toggleSet = (ei: number, si: number) => {
    setExercises(prev => prev.map((ex, i) => {
      if (i !== ei) return ex;
      const sets = ex.sets.map((s, j) => {
        if (j !== si) return s;
        if (!s.done) {
          setRestTimer(120);
          if (s.weight >= ex.pr) {
            setPrExercise(ex.name);
            setTimeout(() => setPrExercise(null), 4000);
          }
        }
        return { ...s, done: !s.done };
      });
      return { ...ex, sets };
    }));
  };

  const updateSet = (ei: number, si: number, field: "weight" | "reps", val: number) => {
    setExercises(prev => prev.map((ex, i) => i !== ei ? ex : {
      ...ex,
      sets: ex.sets.map((s, j) => j !== si ? s : { ...s, [field]: Math.max(0, val) }),
    }));
  };

  const done = exercises.reduce((a, ex) => a + ex.sets.filter(s => s.done).length, 0);
  const total = exercises.reduce((a, ex) => a + ex.sets.length, 0);
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  return (
    <div className="p-6 space-y-4 max-w-3xl relative">
      {/* PR toast */}
      {prExercise && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-[var(--gold)] text-white px-4 py-2.5 rounded-lg font-semibold text-sm shadow-xl">
          <Trophy className="w-4 h-4" />
          שיא אישי חדש — {prExercise}!
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">כוח עליון A</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            <span className="font-mono">{fmt(elapsed)}</span>
            {" "}· {done}/{total} סטים
          </p>
        </div>
        <Btn variant="outline" size="sm" onClick={() => setShowExit(true)}>
          <X className="w-3.5 h-3.5" />
          עצור
        </Btn>
      </div>

      {/* Progress */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{pct}% הושלם</span>
          <span>{total - done} סטים נותרו</span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
        </div>
      </div>

      {/* Rest timer */}
      {restTimer !== null && (
        <Card className="p-3 bg-primary/8 border-primary/25 flex items-center gap-3">
          <Timer className="w-5 h-5 text-primary flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-semibold text-primary mb-0.5">זמן מנוחה</p>
            <p className="text-3xl font-mono font-bold text-primary leading-none">{fmt(restTimer)}</p>
          </div>
          <div className="flex gap-1.5">
            <Btn variant="ghost" size="xs" onClick={() => setRestTimer(null)}>דלג</Btn>
            <Btn variant="outline" size="xs" onClick={() => setRestTimer(120)}>
              <RotateCcw className="w-3 h-3" />
            </Btn>
          </div>
        </Card>
      )}

      {/* Exercise cards */}
      {exercises.map((ex, ei) => {
        const allDone = ex.sets.every(s => s.done);
        return (
          <Card key={ex.id} className={cn("p-4", allDone && "opacity-60")}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <span className={cn("w-6 h-6 rounded flex items-center justify-center text-xs font-bold flex-shrink-0", allDone ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary")}>
                  {allDone ? <Check className="w-3 h-3" /> : ei + 1}
                </span>
                <h3 className="font-semibold">{ex.name}</h3>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-muted-foreground">אחרון: {ex.lastSession}</span>
                <Badge variant="gold">שיא {ex.pr}</Badge>
              </div>
            </div>

            {/* Table header */}
            <div className="grid grid-cols-[1.75rem_1fr_1fr_2.5rem] gap-2 text-xs text-muted-foreground px-1 mb-1.5">
              <span className="text-center">סט</span>
              <span>משקל (ק״ג)</span>
              <span>חזרות</span>
              <span />
            </div>

            {/* Sets */}
            <div className="space-y-1.5">
              {ex.sets.map((set, si) => (
                <div key={si} className={cn("grid grid-cols-[1.75rem_1fr_1fr_2.5rem] gap-2 items-center rounded px-1 py-1.5 transition-colors", set.done && "bg-primary/6")}>
                  <span className="text-xs text-muted-foreground font-mono text-center">{si + 1}</span>
                  <div className="flex items-center gap-1">
                    <button className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors" onClick={() => updateSet(ei, si, "weight", set.weight - 2.5)}>
                      <Minus className="w-3 h-3 text-muted-foreground" />
                    </button>
                    <input
                      dir="ltr"
                      type="number"
                      value={set.weight}
                      onChange={e => updateSet(ei, si, "weight", parseFloat(e.target.value) || 0)}
                      className="w-14 h-6 text-center text-sm font-mono bg-transparent border-b border-border focus:outline-none focus:border-primary text-foreground"
                    />
                    <button className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors" onClick={() => updateSet(ei, si, "weight", set.weight + 2.5)}>
                      <Plus className="w-3 h-3 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="flex items-center gap-1">
                    <button className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors" onClick={() => updateSet(ei, si, "reps", set.reps - 1)}>
                      <Minus className="w-3 h-3 text-muted-foreground" />
                    </button>
                    <input
                      dir="ltr"
                      type="number"
                      value={set.reps}
                      onChange={e => updateSet(ei, si, "reps", parseInt(e.target.value) || 0)}
                      className="w-10 h-6 text-center text-sm font-mono bg-transparent border-b border-border focus:outline-none focus:border-primary text-foreground"
                    />
                    <button className="w-6 h-6 rounded border border-border flex items-center justify-center hover:bg-accent transition-colors" onClick={() => updateSet(ei, si, "reps", set.reps + 1)}>
                      <Plus className="w-3 h-3 text-muted-foreground" />
                    </button>
                  </div>
                  <button
                    className={cn("w-8 h-8 rounded flex items-center justify-center transition-all", set.done ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground hover:border-primary hover:text-primary")}
                    onClick={() => toggleSet(ei, si)}
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </Card>
        );
      })}

      <Btn variant="primary" size="lg" fullWidth onClick={onExit}>
        <CheckCircle className="w-5 h-5" />
        סיים אימון ({pct}% הושלם)
      </Btn>

      {/* Exit confirm */}
      {showExit && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-4">
          <Card className="p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-full bg-[var(--gold)]/15 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[var(--gold)]" />
              </div>
              <h3 className="font-semibold text-lg">לצאת מהאימון?</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-5">ההתקדמות תישמר. האימון יסומן כחלקי.</p>
            <div className="flex gap-2">
              <Btn variant="destructive" size="md" className="flex-1" onClick={onExit}>שמור וצא</Btn>
              <Btn variant="outline" size="md" className="flex-1" onClick={() => setShowExit(false)}>המשך אימון</Btn>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

// ─── History ──────────────────────────────────────────────────────────────────

function HistoryScreen() {
  const [view, setView] = useState<"list" | "chart">("list");

  return (
    <div className="p-6 space-y-5 max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">היסטוריה</h1>
        <div className="flex items-center gap-1.5 bg-muted rounded p-1">
          {(["list", "chart"] as const).map(v => (
            <button key={v} onClick={() => setView(v)} className={cn("px-3 py-1 rounded text-xs font-medium transition-colors", view === v ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
              {v === "list" ? "רשימה" : "גרף"}
            </button>
          ))}
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard label="סה״כ אימונים" value="47" sub="מינואר 2025" />
        <StatCard label="שעות כולל" value="48.5" sub="בממוצע 62 דק׳" />
        <StatCard label="נפח חודשי" value="42K" sub="ק״ג — יולי 2025" accent="green" />
      </div>

      {view === "chart" ? (
        <Card className="p-4">
          <h3 className="text-sm font-semibold mb-3">נפח שבועי — 6 שבועות אחרונים</h3>
          <div dir="ltr">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyVolumeData} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: "var(--muted-foreground)", fontFamily: "Heebo" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip
                  contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 12, direction: "rtl" }}
                  formatter={(v: unknown) => [`${((v as number) / 1000).toFixed(1)}K ק״ג`, "נפח"]}
                  cursor={{ fill: "var(--accent)" }}
                />
                <Bar dataKey="volume" fill="var(--primary)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          {recentWorkouts.map(w => (
            <Card key={w.id} className="p-4 hover:border-primary/30 transition-colors cursor-pointer group">
              <div className="flex items-center gap-4">
                <div className="w-9 h-9 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Dumbbell className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">{w.name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{w.date} · {w.duration} · {w.sets} סטים</p>
                </div>
                <div className="text-left flex-shrink-0">
                  <p className="font-mono font-semibold text-sm">{w.volume} <span className="text-xs font-normal text-muted-foreground">ק״ג</span></p>
                  <p className="text-xs text-muted-foreground">נפח</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Personal Records ─────────────────────────────────────────────────────────

function RecordsScreen() {
  const [selected, setSelected] = useState(0);
  const pr = personalRecords[selected];

  return (
    <div className="p-6 space-y-5 max-w-4xl">
      <h1 className="text-2xl font-bold">שיאים אישיים</h1>

      {/* PR grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {personalRecords.map((r, i) => (
          <Card
            key={r.exercise}
            className={cn("p-4 cursor-pointer transition-all hover:border-[var(--gold)]/40", selected === i && "ring-2 ring-[var(--gold)]/50 border-[var(--gold)]/40")}
            onClick={() => setSelected(i)}
          >
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">{r.exercise}</p>
              {r.isPR && <Trophy className="w-4 h-4 text-[var(--gold)]" />}
            </div>
            <p className="text-3xl font-bold font-mono text-[var(--gold)] leading-none mb-1">{r.weight}</p>
            <p className="text-xs text-muted-foreground mb-2">ק״ג · {r.date}</p>
            <div className="flex items-center gap-1">
              <ArrowUp className="w-3 h-3 text-primary" />
              <span className="text-xs text-primary font-medium">{r.delta} מהשיא הקודם</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Progression chart */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">התקדמות — {pr.exercise}</h3>
          <Badge variant="gold">{pr.weight} ק״ג שיא נוכחי</Badge>
        </div>
        <div dir="ltr">
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={pr.data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "var(--muted-foreground)", fontFamily: "Heebo" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} domain={["dataMin - 10", "dataMax + 5"]} />
              <Tooltip
                contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 12, direction: "rtl" }}
                formatter={(v: unknown) => [`${v} ק״ג`, pr.exercise]}
              />
              <Line type="monotone" dataKey="weight" stroke="var(--gold)" strokeWidth={2.5} dot={{ fill: "var(--gold)", r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

// ─── Body Weight ──────────────────────────────────────────────────────────────

function BodyWeightScreen() {
  const [newWeight, setNewWeight] = useState("");
  const [saved, setSaved] = useState(false);
  const latest = bodyweightData[bodyweightData.length - 1].w;
  const goal = 85;
  const start = 81.2;
  const progress = Math.round(((latest - start) / (goal - start)) * 100);

  const handleSave = () => {
    if (!newWeight) return;
    setSaved(true);
    setNewWeight("");
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-6 space-y-5 max-w-3xl">
      <h1 className="text-2xl font-bold">משקל גוף</h1>

      <div className="grid grid-cols-3 gap-3">
        <StatCard label="משקל נוכחי" value={`${latest}`} sub="ק״ג" icon={Scale} accent="green" />
        <StatCard label="יעד" value={`${goal}`} sub="ק״ג" />
        <StatCard label="נותר ליעד" value={`${(goal - latest).toFixed(1)}`} sub="ק״ג" />
      </div>

      <Card className="p-4">
        <div className="flex items-center justify-between mb-2.5">
          <p className="text-sm font-medium">התקדמות לקראת יעד ({start} → {goal} ק״ג)</p>
          <span className="text-sm font-mono font-bold text-primary">{progress}%</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress}%` }} />
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3">40 ימים אחרונים</h3>
        <div dir="ltr">
          <ResponsiveContainer width="100%" height={190}>
            <AreaChart data={bodyweightData} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
              <defs>
                <linearGradient id="wGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.18} />
                  <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "var(--muted-foreground)", fontFamily: "Heebo" }} axisLine={false} tickLine={false} />
              <YAxis domain={[80, 86]} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 12, direction: "rtl" }}
                formatter={(v: unknown) => [`${v} ק״ג`, "משקל"]}
              />
              <Area type="monotone" dataKey="w" stroke="var(--primary)" strokeWidth={2} fill="url(#wGrad)" dot={false} activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3">הוסף מדידה</h3>
        <div className="flex gap-2">
          <input
            dir="ltr"
            type="number"
            value={newWeight}
            onChange={e => setNewWeight(e.target.value)}
            placeholder="83.2"
            className="flex-1 h-9 bg-input-background border border-border rounded px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <Btn variant="primary" size="md" onClick={handleSave} disabled={!newWeight}>
            {saved ? <CheckCircle className="w-4 h-4" /> : "שמור"}
          </Btn>
        </div>
        {saved && <p className="text-xs text-primary mt-2">נשמר בהצלחה</p>}
      </Card>
    </div>
  );
}

// ─── Supplements ──────────────────────────────────────────────────────────────

function SupplementsScreen() {
  const [items, setItems] = useState(supplements);

  const toggle = (id: number) => setItems(prev => prev.map(s => s.id === id ? { ...s, active: !s.active } : s));

  const todayLog = [
    { time: "07:30", name: "קריאטין מונוהידראט", done: true },
    { time: "07:30", name: "ויטמין D3", done: true },
    { time: "17:00", name: "חלבון מי גבינה", done: false },
    { time: "22:00", name: "אומגה 3", done: false },
  ];

  return (
    <div className="p-6 space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">תוספי תזונה</h1>
        <Btn variant="primary" size="sm">
          <Plus className="w-3.5 h-3.5" />
          הוסף תוסף
        </Btn>
      </div>

      {/* Today's log */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">יומן היום</h3>
          <span className="text-xs text-muted-foreground">2/4 נלקחו</span>
        </div>
        <div className="space-y-2.5">
          {todayLog.map((entry, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground font-mono w-11 flex-shrink-0">{entry.time}</span>
              <span className={cn("flex-1 text-sm", !entry.done && "text-muted-foreground")}>{entry.name}</span>
              {entry.done
                ? <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                : <div className="w-4 h-4 rounded-full border-2 border-border flex-shrink-0" />
              }
            </div>
          ))}
        </div>
      </Card>

      {/* Supplement list */}
      <div>
        <SectionLabel>רשימת תוספים</SectionLabel>
        <div className="space-y-2">
          {items.map(s => (
            <Card key={s.id} className={cn("p-3.5 flex items-center gap-3 transition-opacity", !s.active && "opacity-50")}>
              <div className="w-1.5 h-10 rounded-full bg-primary flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{s.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.dose} · {s.timing} · {s.freq}</p>
              </div>
              <div className="flex items-center gap-2.5 flex-shrink-0">
                <Badge variant={s.active ? "green" : "muted"}>{s.active ? "פעיל" : "כבוי"}</Badge>
                <Toggle value={s.active} onChange={() => toggle(s.id)} />
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Profile ──────────────────────────────────────────────────────────────────

function ProfileScreen({ isDark, setIsDark }: { isDark: boolean; setIsDark: (v: boolean) => void }) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  return (
    <div className="p-6 space-y-5 max-w-2xl">
      <h1 className="text-2xl font-bold">פרופיל והגדרות</h1>

      {/* User card */}
      <Card className="p-5">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
            <User className="w-7 h-7 text-primary" />
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-lg leading-tight">עמית לוי</h2>
            <p className="text-sm text-muted-foreground">מתאמן מינואר 2023 · 47 אימונים</p>
          </div>
          <Btn variant="outline" size="sm">
            <Edit3 className="w-3.5 h-3.5" />
            ערוך
          </Btn>
        </div>
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border text-center">
          <div>
            <p className="text-2xl font-bold font-mono text-primary">178</p>
            <p className="text-xs text-muted-foreground">גובה (ס״מ)</p>
          </div>
          <div>
            <p className="text-2xl font-bold font-mono">83.1</p>
            <p className="text-xs text-muted-foreground">משקל (ק״ג)</p>
          </div>
          <div>
            <p className="text-2xl font-bold font-mono">28</p>
            <p className="text-xs text-muted-foreground">גיל</p>
          </div>
        </div>
      </Card>

      {/* Settings list */}
      <Card className="divide-y divide-border overflow-hidden">
        {[
          {
            label: "מצב לילה",
            desc: isDark ? "ממשק כהה — פעיל" : "ממשק בהיר — פעיל",
            icon: isDark ? Moon : Sun,
            action: <Toggle value={isDark} onChange={setIsDark} />,
          },
          {
            label: "שפה",
            desc: "עברית (Hebrew)",
            icon: Settings,
            action: <Badge variant="muted">עברית</Badge>,
          },
          {
            label: "התראות",
            desc: "תזכורות אימון ותוספים",
            icon: Bell,
            action: <Badge variant="green">פעיל</Badge>,
          },
          {
            label: "יחידות משקל",
            desc: "קילוגרם",
            icon: Scale,
            action: <Badge variant="muted">ק״ג</Badge>,
          },
          {
            label: "מצב אופליין",
            desc: "סנכרון אוטומטי פעיל",
            icon: WifiOff,
            action: <Badge variant="blue">מסונכרן</Badge>,
          },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-3 p-4">
            <item.icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            {item.action}
          </div>
        ))}
      </Card>

      {/* Danger zone */}
      <Card className="p-4 border-destructive/25">
        <h3 className="text-xs font-semibold text-destructive uppercase tracking-wide mb-3">פעולות מסוכנות</h3>
        <Btn variant="destructive" size="sm" onClick={() => setShowDeleteConfirm(true)}>
          <Trash2 className="w-3.5 h-3.5" />
          מחק את כל הנתונים
        </Btn>
      </Card>

      {/* Delete confirm */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-4">
          <Card className="p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 rounded-full bg-destructive/10 flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-destructive" />
              </div>
              <h3 className="font-semibold">מחיקת כל הנתונים</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-5">פעולה זו בלתי הפיכה. כל הנתונים, האימונים, השיאים והתוכניות יימחקו לצמיתות.</p>
            <div className="flex gap-2">
              <Btn variant="destructive" size="md" className="flex-1" onClick={() => setShowDeleteConfirm(false)}>מחק הכל</Btn>
              <Btn variant="outline" size="md" className="flex-1" onClick={() => setShowDeleteConfirm(false)}>ביטול</Btn>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

// ─── AI Coach ─────────────────────────────────────────────────────────────────

function AIScreen() {
  const [messages, setMessages] = useState(aiMessages);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);

  const send = () => {
    if (!input.trim()) return;
    const userMsg = { role: "user" as const, text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMessages(prev => [...prev, {
        role: "ai" as const,
        text: "שאלה מעניינת. בהתבסס על הנתונים שלך, ממליץ לבחון את נפח האימון השבועי ולהבטיח ששינה ומנוחה תואמות את העומס.",
      }]);
    }, 1500);
  };

  const suggestions = ["הצע תרגיל חלופי", "ניתח את השיאים שלי", "כמה מנוחה אני צריך?", "בנה לי מיקרו-מחזור"];

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] md:h-screen max-w-2xl">
      {/* Header */}
      <div className="p-5 pb-4 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded bg-primary/10 flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-bold">מאמן AI</h1>
            <p className="text-xs text-muted-foreground">מבוסס על 47 אימונים, שיאים ונתוני גוף</p>
          </div>
          <div className="mr-auto flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary" />
            <span className="text-xs text-muted-foreground">מחובר</span>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={cn("flex", msg.role === "user" ? "justify-start" : "justify-end")}>
            <div className={cn(
              "max-w-[82%] rounded-lg px-4 py-2.5 text-sm leading-relaxed",
              msg.role === "user" ? "bg-muted text-foreground" : "bg-primary text-primary-foreground"
            )}>
              {msg.text}
            </div>
          </div>
        ))}
        {typing && (
          <div className="flex justify-end">
            <div className="bg-primary/15 text-primary rounded-lg px-4 py-2.5 text-sm flex items-center gap-1.5">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              מעבד...
            </div>
          </div>
        )}
      </div>

      {/* Suggestions */}
      <div className="px-5 pb-2 flex-shrink-0">
        <div className="flex flex-wrap gap-2">
          {suggestions.map(s => (
            <button
              key={s}
              onClick={() => setInput(s)}
              className="text-xs px-3 py-1.5 rounded-full border border-border text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="p-5 pt-3 border-t border-border flex-shrink-0">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="שאל על אימון, תזונה, התאוששות..."
            className="flex-1 h-10 bg-input-background border border-border rounded px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <Btn variant="primary" size="md" onClick={send} disabled={!input.trim()}>
            <Send className="w-4 h-4" />
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ─── Navigation config ────────────────────────────────────────────────────────

const NAV: { id: Screen; label: string; icon: ElementType }[] = [
  { id: "dashboard", label: "לוח בקרה", icon: LayoutDashboard },
  { id: "plans", label: "תוכניות", icon: CalendarDays },
  { id: "history", label: "היסטוריה", icon: Clock },
  { id: "records", label: "שיאים", icon: Trophy },
  { id: "bodyweight", label: "משקל גוף", icon: Scale },
  { id: "supplements", label: "תוספים", icon: Pill },
  { id: "ai", label: "מאמן AI", icon: Bot },
  { id: "profile", label: "פרופיל", icon: User },
];

const MOBILE_NAV: { id: Screen; label: string; icon: ElementType }[] = [
  { id: "dashboard", label: "בקרה", icon: LayoutDashboard },
  { id: "history", label: "היסטוריה", icon: Clock },
  { id: "records", label: "שיאים", icon: Trophy },
  { id: "supplements", label: "תוספים", icon: Pill },
  { id: "profile", label: "פרופיל", icon: User },
];

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [isDark, setIsDark] = useState(true);
  const [workoutActive, setWorkoutActive] = useState(false);
  const [offlineMode] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  const navigate = (s: Screen) => { setScreen(s); setWorkoutActive(false); };

  const renderScreen = () => {
    if (workoutActive) return <WorkoutScreen onExit={() => { setWorkoutActive(false); setScreen("history"); }} />;
    switch (screen) {
      case "dashboard": return <DashboardScreen onStartWorkout={() => setWorkoutActive(true)} />;
      case "plans": return <PlansScreen />;
      case "history": return <HistoryScreen />;
      case "records": return <RecordsScreen />;
      case "bodyweight": return <BodyWeightScreen />;
      case "supplements": return <SupplementsScreen />;
      case "profile": return <ProfileScreen isDark={isDark} setIsDark={setIsDark} />;
      case "ai": return <AIScreen />;
      default: return <DashboardScreen onStartWorkout={() => setWorkoutActive(true)} />;
    }
  };

  return (
    <div dir="rtl" className="flex min-h-screen bg-background text-foreground overflow-hidden" style={{ fontFamily: "'Heebo', sans-serif" }}>
      {/* Desktop sidebar — right side in RTL */}
      <aside className="hidden md:flex flex-col w-56 min-h-screen bg-card border-l border-border flex-shrink-0">
        {/* Logo */}
        <div className="px-4 py-5 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-primary flex items-center justify-center flex-shrink-0">
              <Dumbbell className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-extrabold text-base tracking-tight">Tiger8</span>
          </div>
        </div>

        {/* Workout CTA */}
        <div className="px-3 py-3 border-b border-border">
          <Btn
            variant={workoutActive ? "secondary" : "primary"}
            size="sm"
            fullWidth
            onClick={() => workoutActive ? navigate("dashboard") : setWorkoutActive(true)}
          >
            <Play className="w-3.5 h-3.5" />
            {workoutActive ? "אימון פעיל" : "התחל אימון"}
          </Btn>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
          {NAV.map(item => {
            const active = !workoutActive && screen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded text-sm transition-colors text-right",
                  active
                    ? "bg-primary/10 text-primary font-semibold"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                <item.icon className="w-4 h-4 flex-shrink-0" />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-2 border-t border-border space-y-0.5">
          {offlineMode && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-destructive/10 text-destructive text-xs mb-1">
              <WifiOff className="w-3.5 h-3.5" />
              מצב לא מקוון
            </div>
          )}
          <button
            onClick={() => setIsDark(!isDark)}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {isDark ? "מצב יום" : "מצב לילה"}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto min-h-screen pb-20 md:pb-0">
        {/* Mobile header */}
        <header className="md:hidden sticky top-0 z-40 bg-card/95 backdrop-blur border-b border-border px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
              <Dumbbell className="w-3.5 h-3.5 text-primary-foreground" />
            </div>
            <span className="font-extrabold text-sm">Tiger8</span>
          </div>
          <div className="flex items-center gap-2">
            {workoutActive && (
              <Badge variant="green">
                <Activity className="w-3 h-3" />
                אימון פעיל
              </Badge>
            )}
            <button
              onClick={() => setIsDark(!isDark)}
              className="w-8 h-8 rounded flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {renderScreen()}
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-card/95 backdrop-blur border-t border-border flex items-center justify-around px-1 pt-2 pb-3">
        {MOBILE_NAV.map(item => {
          const active = !workoutActive && screen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 px-2 py-1.5 rounded min-w-[52px] transition-colors",
                active ? "text-primary" : "text-muted-foreground"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] leading-none">{item.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => workoutActive ? navigate("dashboard") : setWorkoutActive(true)}
          className={cn(
            "flex flex-col items-center gap-0.5 px-2 py-1.5 rounded min-w-[52px] transition-colors",
            workoutActive ? "text-primary" : "text-muted-foreground"
          )}
        >
          <div className={cn("w-8 h-8 rounded-full flex items-center justify-center -mt-4 border-2 border-border", workoutActive ? "bg-primary text-primary-foreground border-primary" : "bg-card")}>
            <Play className="w-4 h-4" />
          </div>
          <span className="text-[10px] leading-none mt-1">{workoutActive ? "ממשיך" : "אימון"}</span>
        </button>
      </nav>
    </div>
  );
}
